import numpy as np


def three_means(vecs):
    '''
    :param vecs: 数据集
    :return: 将数据集聚类为3类
    '''
    max_iteration = 50                              # 最多迭代50次
    cur_iteration = 0                               # 当前迭代次数
    m, n = vecs.shape                               # m为数据集的条数，n为每条数据的维度
    last_mean_vecs = vecs[(0, m // 2, m-1), :]      # 上一次聚类后每个类的中心
    last_clusters = None                            # 上一次的聚类结果

    while True:
        cur_iteration += 1
        cur_clusters = [[], [], []]                 # 这次的聚类结果
        cur_mean_vecs = np.zeros((3, n), dtype=np.float_)   # 这次聚类后每个类的中心

        # 根据上一次聚类后的中心进行聚类
        for i in range(n):
            min_dist = 1000
            min_index = 0
            for j in range(3):
                dist = np.sqrt(np.sum((vecs[i, :] - last_mean_vecs[j, :]) ** 2))
                if dist < min_dist:
                    min_dist = dist
                    min_index = j
            cur_clusters[min_index].append(i)       # 加入距离中心最小的类
        for j in range(3):                          # 重新计算本次聚类的中心
            cur_mean_vecs[j, :] = np.mean(vecs[cur_clusters[j], :], 0)

        # 聚类结果稳定就结束迭代
        if last_clusters == cur_clusters or cur_iteration >= max_iteration:
            return cur_clusters

        # 更新
        last_mean_vecs = cur_mean_vecs
        last_clusters = cur_clusters


def pca(vec, k):
    '''
    :param vec: 数据集 nxd
    :param k: 每条数据压缩成k维
    :return: 压缩后的数据集 nxk
    '''
    mean = np.mean(vec, 0)                          # 数据集的均值
    centered_data = vec - mean                      # 中心化
    [_, sigma, vT] = np.linalg.svd(centered_data)   # svd分解
    sigma_2 = pow(sigma, 2) / vec.shape[0]
    sort_index = np.argsort(-sigma_2)               # 根据特征值排序
    k_vT = vT[sort_index[: k], :]                   # 选取前k大特征值对应的k个特征向量
    return np.matmul(k_vT, vec.T).T                 # 压缩到k维


def get_hist_vector(reshape_img):
    '''
    :param reshape_img: 一维的图像
    :return: 归一化的颜色直方图特征
    '''
    # 统计
    histogram = [0 for _ in range(64)]
    for pixel in reshape_img:
        red = pixel[0] // 64
        green = pixel[1] // 64
        blue = pixel[2] // 64
        histogram[red * 4 * 4 + green * 4 + blue] += 1
    histogram = np.array(histogram, dtype=np.float_)

    # 归一化
    histogram /= np.sqrt(np.sum(histogram ** 2))

    return histogram




