import cv2
from PIL import Image
import matplotlib.pyplot as plt
from untils import *


if __name__ == "__main__":
    imgs_path = "../data/imgs/"                                     # 图像路径
    sift = cv2.xfeatures2d.SIFT_create()                            # sift特征提取器

    for i in range(10):
        img = cv2.imread(imgs_path + str(13 + i * 10) + ".png")     # 读取图像
        gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)            # 转为灰度图
        kp, des = sift.detectAndCompute(gray_img, None)             # 提取特征点以及描述子
        img = img[:, :, (2, 1, 0)]                                  # BGR -> RGB
        height, width, _ = img.shape                                # 图像的高、宽

        fit_kp = []                                                 # 能够提取17x17patch的特征点
        sift_vec = []                                               # 对应的sift特征
        color_vec = []                                              # 对应patch的归一化颜色直方图特征
        fit_kp_vec = []                                             # 对应patch的总特征
        for j in range(len(kp)):
            x = int(kp[j].pt[0])
            y = int(kp[j].pt[1])
            if 8 <= x <= width - 9 and 8 <= y <= height - 9:
                fit_kp.append((x, y))
                sift_vec.append(des[j])

                sub_img = img[y - 8: y + 9, x - 8: x + 9, :]
                sub_img = np.reshape(sub_img, (17 * 17, 3))
                color_vec.append(get_hist_vector(sub_img))

        sift_vec = np.array(sift_vec)
        extract_sift_vec = pca(sift_vec, 10)
        for j in range(len(fit_kp)):
            vec = extract_sift_vec[j, :]
            vec = vec / np.mean(np.sum(vec ** 2))                       # 归一化
            fit_kp_vec.append(np.concatenate([vec, color_vec[j]], 0))   # 合并两个特征向量
        fit_kp_vec = np.array(fit_kp_vec)

        clusters = three_means(fit_kp_vec)                              # 聚类

        # 作图
        max_len = max(len(clusters[0]), len(clusters[1]), len(clusters[2]))
        show_clusters = 255 * np.ones((17 * 3 + 20, 17 * max_len + 5 * (max_len - 1), 3), dtype=np.uint8)
        h, w, _ = show_clusters.shape
        for j in range(3):
            for k in range(len(clusters[j])):
                x, y = fit_kp[clusters[j][k]]
                show_clusters[j * 27: j * 27 + 17, k * 22: k * 22 + 17, :] = img[y - 8: y + 9, x-8: x + 9, :]
        # 放大
        show_clusters = Image.fromarray(show_clusters, mode="RGB")
        show_clusters = np.array(show_clusters.resize((w * 5, h * 8), Image.ANTIALIAS))

        plt.figure(figsize=(20, 10))
        plt.imshow(show_clusters)

    plt.show()



