from segmentation import *


def make_data(image_path, gt_path):
    sigma = 0.8                 # 高斯滤波参数
    min_size = 20               # 每个区域不少于20个像素
    k = 300                     # 阈值参数

    while True:                 # 分割出的区域的数量必须在50~100之间，否则调整参数k
        img, _, disjoint_set = segment(image_path, sigma, k, min_size)  # 原图，并查集
        if disjoint_set.get_set_size() > 100:               # 数量过多，说明阈值过小，调大
            k += 50
        elif disjoint_set.get_set_size() < 50:              # 数量过少，说明阈值过大，调小
            k -= 50
        else:
            break

    img = img[:, :, (2, 1, 0)]                              # BGR -> RGB
    height, width, _ = img.shape                            # 图像的高、宽
    reshape_img = np.reshape(img, (height * width, 3))      # 拉成一维的图像
    # 获取全图颜色直方图的特征向量
    global_vec = get_hist_vector(reshape_img)

    region_map = {}                                         # 记录每个区域内的像素
    gt_img = cv2.imread(gt_path)                            # 真正的gt
    region_vec = []                                         # 每个区域的特征向量
    labels = []                                             # 每个区域的标签：前景还是背景
    # 记录每个区域内的像素
    for j in range(height * width):
        leader = disjoint_set.find(j)
        if leader in region_map:
            region_map[leader].append(j)
        else:
            region_map[leader] = [j]
    # 获取区域颜色直方图的特征向量及标签
    for key in region_map.keys():
        value = region_map[key]
        region_img = np.zeros([len(value), 3], dtype=np.uint8)      # 区域子图
        label = 0
        for j in range(len(value)):
            region_img[j] = reshape_img[value[j]]
            if np.sum(gt_img[value[j] // width, value[j] % width, :]) == 0:
                label -= 1
            else:
                label += 1
        # 区域的特征向量
        region_vec.append(np.array(global_vec + get_hist_vector(region_img)))

        if label > 0:                   # 大于50%的像素点为前景，则该区域为前景区域
            labels.append(1)
        else:                           # 否则为背景区域
            labels.append(0)

    data = pca(np.array(region_vec), 50)                # 压缩降维

    return data, labels, gt_img, list(region_map.values()), disjoint_set


def pca(vec, k):
    '''
    :param vec: 数据集 nxd
    :param k: 每条数据压缩成k维
    :return: 压缩后的数据集 nxk
    '''
    mean = np.mean(vec, 0)                          # 数据集的均值
    centered_data = vec - mean                      # 中心化
    [_, sigma, vT] = np.linalg.svd(centered_data)   # svd分解
    sigma_2 = pow(sigma, 2) / vec.shape[0]
    sort_index = np.argsort(-sigma_2)               # 根据特征值排序
    k_vT = vT[sort_index[: k], :]                   # 选取前k大特征值对应的k个特征向量
    return np.matmul(k_vT, vec.T).T                 # 压缩到k维


def get_hist_vector(reshape_img):
    '''
    :param reshape_img: 一维的图像
    :return: 归一化的颜色直方图特征
    '''
    # 统计
    histogram = [0 for _ in range(512)]
    for pixel in reshape_img:
        red = pixel[0] // 32
        green = pixel[1] // 32
        blue = pixel[2] // 32
        histogram[red * 8 * 8 + green * 8 + blue] += 1

    # 归一化
    hist_sum = 0
    for value in histogram:
        hist_sum += value ** 2
    hist_sum = math.sqrt(hist_sum)
    for i in range(512):
        histogram[i] /= hist_sum

    return histogram


