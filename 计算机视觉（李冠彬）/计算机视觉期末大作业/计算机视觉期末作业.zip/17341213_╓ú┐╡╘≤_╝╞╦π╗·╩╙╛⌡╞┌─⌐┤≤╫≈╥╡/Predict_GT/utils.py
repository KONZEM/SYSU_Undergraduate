import math
import random


class Edge:
    def __init__(self, vertex1, vertex2, diff):
        '''
        :param vertex1: 像素点的位置
        :param vertex2: 像素点的位置
        :param diff: 两个像素点的不相似度
        '''
        self.vertex1 = vertex1
        self.vertex2 = vertex2
        self.diff = diff


class Disjoint_Set:
    class Element:
        def __init__(self, leader):
            self.size = 1                   # leader是自己（最高级）才有用
            self.leader = leader            # 该元素的leader
            self.rank = 0                   # leader是自己（最高级）才有用

    def __init__(self, num_vertices):
        '''
        初始化num_vertices个元素
        '''
        self.num = num_vertices
        self.set = []
        for i in range(self.num):
            element = Disjoint_Set.Element(i)
            self.set.append(element)

    def find(self, x):
        '''
        :return: x的最高级leader
        '''
        _x = x
        while _x != self.set[_x].leader:
            _x = self.set[_x].leader
        self.set[x].leader = _x             # 修改x的leader为最高级leader
        return _x

    def union(self, x, y):
        '''
        合并x所在的集合和y所在的集合（x和y都是所在集合的最高级leader）
        :return: 合并后的集合的最高级leader
        '''
        self.num -= 1                       # 合并导致集合数减一
        if self.set[x].rank > self.set[y].rank:
            self.set[y].leader = x
            self.set[x].size += self.set[y].size
            return x
        else:
            self.set[x].leader = y
            self.set[y].size += self.set[x].size
            if self.set[x].rank == self.set[y].rank:
                self.set[y].rank += 1
            return y

    def get_ele_size(self, x):
        '''
        :return: x所在集合的元素数量
        '''
        return self.set[x].size

    def get_set_size(self):
        '''
        :return: 所有集合的数量
        '''
        return self.num


def cal_diff(pixel1, pixel2):
    '''
    :param pixel1: 像素值
    :param pixel2: 像素值
    :return: 两个像素值的欧氏距离
    '''
    return math.sqrt(pow(pixel1[0] - pixel2[0], 2) +
                     pow(pixel1[1] - pixel2[1], 2) +
                     pow(pixel1[2] - pixel2[2], 2))


def get_ncolor(n):
    '''
    :param n: 代表n种颜色
    :return: n中RGB颜色
    '''
    num_color = 0
    colors = []
    while num_color < n:
        color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        flag = True
        for each in colors:
            if each == color:       # 该颜色已有，舍去
                flag = False
        if flag:
            colors.append(color)
            num_color += 1
    return tuple(colors)
