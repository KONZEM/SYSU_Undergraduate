import os
import matplotlib.pyplot as plt
from extract_vector import *
from model import *
from iou import *


if __name__ == "__main__":
    image_path = "../data/imgs/"                        # 图像路径
    gt_path = "../data/gt/"                             # gt路径
    train_path = "./train_data.txt"                     # 训练数据路径
    test_path = "./test_data.txt"                       # 测试数据路径

    # 制作训练数据
    if not os.path.exists(train_path):
        f_train = open(train_path, "w")
        for i in range(1, 1001):
            if i % 10 == 3 and (i // 10) % 10 == 1:     # 测试集跳过
                continue
            print("start " + str(i) + "...")
            # 50维的特征向量，前景还是背景的标签
            data, labels, _, _, _ = make_data(image_path + str(i) + ".png", gt_path + str(i) + ".png")
            l = len(labels)
            for j in range(l):
                for each in data[j]:
                    f_train.write(str(round(each, 2)) + " ")
                f_train.write(str(labels[j]) + "\n")
            print("finish " + str(i) + "...\n")
        f_train.close()

    # # 制作测试数据
    # if not os.path.exists(test_path):
    #     f_test = open(test_path, "w")
    #     for i in range(13, 1001, 100):
    #         print("start " + str(i) + "...")
    #         # 50维的特征向量，前景还是背景的标签
    #         data, labels, _, _, _ = make_data(image_path + str(i) + ".png", gt_path + str(i) + ".png")
    #         l = len(labels)
    #         for j in range(l):
    #             for each in data[j]:
    #                 f_test.write(str(round(each, 2)) + " ")
    #             f_test.write(str(labels[j]) + "\n")
    #         f_test.write("---\n")
    #         print("finish " + str(i) + "...\n")
    #     f_test.close()
    #
    # # softmax模型
    # model = Model1(train_path, test_path)
    # model.train()
    # model.test()

    # knn模型
    model = Model2(train_path)
    for i in range(10):
        # 50维特征向量，前景还是背景标签，真正的gt，每个区域内的像素，并查集
        data, labels, gt_img, regions, disjoint_set = make_data(image_path + str(13 + i * 100) + ".png",
                                                                gt_path + str(13 + i * 100) + ".png")
        height, width, _ = gt_img.shape
        predict_gt = np.zeros((height, width), dtype=np.uint8)      # 预测的gt
        # 基于分割图和真正的gt生成的gt
        _, new_gt_img, _ = cal_iou(gt_path + str(13 + i * 100) + ".png", disjoint_set)

        accuracy = 0
        l = len(labels)
        for j in range(l):
            predict = model.test(data[j, :])
            # 预测为前景，赋颜色为白色
            if predict == 1:
                for p in regions[j]:
                    predict_gt[p // width, p % width] = 255
            if predict == labels[j]:
                accuracy += 1
            print(predict, end=" ")
        print()
        for each in labels:
            print(each, end=" ")
        print()

        fig = plt.figure(figsize=(7, 6))
        subfig = fig.add_subplot(2, 2, 1)
        plt.imshow(predict_gt, cmap="gray")
        subfig.set_title("prediction")
        subfig = fig.add_subplot(2, 2, 2)
        plt.imshow(new_gt_img, cmap="gray")
        subfig.set_title("based on segmented image and ground truth")
        subfig = fig.add_subplot(2, 2, 3)
        plt.imshow(gt_img)
        subfig.set_title("ground truth")

        if i == 0:
            print(str(i + 1) + "st accuracy: ",
                  float(accuracy) / float(l))
        elif i == 1:
            print(str(i + 1) + "nd accuracy: ",
                  float(accuracy) / float(l))
        elif i == 2:
            print(str(i + 1) + "rd accuracy: ",
                  float(accuracy) / float(l))
        else:
            print(str(i + 1) + "th accuracy: ",
                  float(accuracy) / float(l))
        print()

    plt.show()

    # # Random Forest模型
    # model = Model3(train_path)
    # for i in range(10):
    #     # 50维特征向量，前景还是背景标签，真正的gt，每个区域内的像素，并查集
    #     data, labels, gt_img, regions, disjoint_set = make_data(image_path + str(13 + i * 100) + ".png",
    #                                                             gt_path + str(13 + i * 100) + ".png")
    #     height, width, _ = gt_img.shape
    #     predict_gt = np.zeros((height, width), dtype=np.uint8)        # 预测的gt
    #     # 基于分割图和真正的gt生成的gt
    #     _, new_gt_img, _ = cal_iou(gt_path + str(13 + i * 100) + ".png", disjoint_set)
    #
    #     accuracy = 0
    #     predict = model.test(data)
    #     l = len(labels)
    #     for j in range(l):
    #         # 预测为前景，赋颜色为白色
    #         if predict[j] == 1:
    #             for p in regions[j]:
    #                 predict_gt[p // width, p % width] = 255
    #         if predict[j] == labels[j]:
    #             accuracy += 1
    #         print(predict[j], end=" ")
    #     print()
    #     for each in labels:
    #         print(each, end=" ")
    #     print()
    #
    #     fig = plt.figure(figsize=(7, 6))
    #     subfig = fig.add_subplot(2, 2, 1)
    #     plt.imshow(predict_gt, cmap="gray")
    #     subfig.set_title("prediction")
    #     subfig = fig.add_subplot(2, 2, 2)
    #     plt.imshow(new_gt_img, cmap="gray")
    #     subfig.set_title("based on segmented image and ground truth")
    #     subfig = fig.add_subplot(2, 2, 3)
    #     plt.imshow(gt_img)
    #     subfig.set_title("ground truth")
    #
    #     if i == 0:
    #         print(str(i + 1) + "st accuracy: ",
    #               float(accuracy) / float(l))
    #     elif i == 1:
    #         print(str(i + 1) + "nd accuracy: ",
    #               float(accuracy) / float(l))
    #     elif i == 2:
    #         print(str(i + 1) + "rd accuracy: ",
    #               float(accuracy) / float(l))
    #     else:
    #         print(str(i + 1) + "th accuracy: ",
    #               float(accuracy) / float(l))
    #     print()
    #
    # plt.show()
