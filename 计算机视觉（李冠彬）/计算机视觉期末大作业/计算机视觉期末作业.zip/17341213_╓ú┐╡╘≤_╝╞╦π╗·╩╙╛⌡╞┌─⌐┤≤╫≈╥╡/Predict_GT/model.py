import numpy as np
import random
from sklearn.ensemble import RandomForestClassifier


class Model1:
    '''
    softmax模型
    '''
    def __init__(self, train_path, test_path):
        self.lr = 0.01                                  # 学习率
        self.train_data = []                            # 训练数据
        self.train_label = []                           # 训练标签
        self.test_data = []                             # 测试数据
        self.test_label = []                            # 测试标签
        self.test_sep = [0]                             # 用于区分不同张图像的测试数据
        # self.w = np.random.rand(2, 50)
        self.w = np.ones((2, 50), dtype=np.float_)      # 全连接层weight
        self.b = np.zeros((2, 1), dtype=np.float_)      # 全连接层bias

        # 读取训练数据
        f = open(train_path, "r")
        for line in f.readlines():
            values = line.split()
            tmp_list = []
            for i in range(len(values) - 1):
                tmp_list.append(float(values[i]))
            self.train_data.append(tmp_list)
            if int(values[-1]) == 0:
                self.train_label.append([1, 0])
            else:
                self.train_label.append([0, 1])
        f.close()

        # 读取测试数据
        f = open(test_path, "r")
        for line in f.readlines():
            values = line.split()
            if len(values) == 1 and values[0] == "---":
                self.test_sep.append(len(self.test_data))
                continue
            tmp_list = []
            for i in range(len(values) - 1):
                tmp_list.append(float(values[i]))
            self.test_data.append(tmp_list)
            self.test_label.append(int(values[-1]))
        f.close()

        self.train_length = len(self.train_data)
        self.test_length = len(self.test_data)
        self.train_data = np.array(self.train_data, dtype=np.float_)
        self.train_label = np.array(self.train_label, dtype=np.float_)
        self.test_data = np.array(self.test_data, dtype=np.float_)
        self.test_label = np.array(self.test_label, dtype=np.float_)

    def train(self):
        # mse = 1.0
        ce = 1.0
        # while mse > 1e-2:
        # while ce > 1e-2:
        for _ in range(10):
            # mse = 0.0
            ce = 0.0
            # 随机抽取 self.train_length//10 条训练数据
            sample = [i for i in range(self.train_length)]
            sample = random.sample(sample, self.train_length // 10)
            train_data = self.train_data[sample, :]
            train_label = self.train_label[sample, :]

            # 训练
            for i in range(self.train_length // 10):
                per_data = np.reshape(train_data[i, :], (-1, 1))
                per_label = np.reshape(train_label[i, :], (-1, 1))
                res = np.matmul(self.w, per_data) + self.b          # 全连接层输出
                _res = np.exp(res - np.max(res))                    # 防止溢出
                softmax_res = _res / np.sum(_res)                   # softmax输出
                # # mse损失函数 计算梯度 更新参数
                # mse += np.mean((softmax_res - per_label) ** 2)
                # dw1 = (per_label[0, 0] - softmax_res[0, 0]) * softmax_res[0, 0] * \
                #       res[0, 0] * res[1, 0] / pow(res[0, 0] + res[1, 0], 2) * train_data[i, :]
                # dw2 = (per_label[1, 0] - softmax_res[1, 0]) * softmax_res[1, 0] * \
                #       res[0, 0] * res[1, 0] / pow(res[0, 0] + res[1, 0], 2) * train_data[i, :]
                # dw = np.stack([dw1, dw2], 0)
                # db1 = [(per_label[0, 0] - softmax_res[0, 0]) * softmax_res[0, 0] * \
                #       res[0, 0] * res[1, 0] / pow(res[0, 0] + res[1, 0], 2)]
                # db2 = [(per_label[1, 0] - softmax_res[1, 0]) * softmax_res[1, 0] * \
                #       res[0, 0] * res[1, 0] / pow(res[0, 0] + res[1, 0], 2)]
                # db = np.stack([db1, db2], 0)
                # # 交叉熵损失函数 计算梯度 更新参数
                ce -= np.mean(per_label * np.log(softmax_res + 0.01))
                dw1 = per_label[0, 0] / (softmax_res[0, 0] + 0.01) * \
                       res[0, 0] * res[1, 0] / pow(res[0, 0] + res[1, 0], 2) * train_data[i, :]
                dw2 = per_label[1, 0] / (softmax_res[0, 0] + 0.01) * \
                       res[0, 0] * res[1, 0] / pow(res[0, 0] + res[1, 0], 2) * train_data[i, :]
                db1 = [per_label[0, 0] / (softmax_res[0, 0] + 0.01) * \
                       res[0, 0] * res[1, 0] / pow(res[0, 0] + res[1, 0], 2)]
                db2 = [per_label[1, 0] / (softmax_res[0, 0] + 0.01) * \
                       res[0, 0] * res[1, 0] / pow(res[0, 0] + res[1, 0], 2)]
                dw = np.stack([dw1, dw2], 0)
                db = np.stack([db1, db2], 0)
                self.w += self.lr * dw
                self.b += self.lr * db

            # mse /= float(self.train_length // 10)
            # print(mse)
            ce /= float(self.train_length // 10)
            print(ce)
            print()

    def test(self):
        for s in range(len(self.test_sep) - 1):                 # 处理每张图的分割区域
            print(self.test_sep[s], self.test_sep[s + 1])
            accuracy = 0
            for i in range(self.test_sep[s], self.test_sep[s + 1]):
                per_data = np.reshape(self.train_data[i, :], (-1, 1))
                res = np.matmul(self.w, per_data) + self.b
                _res = np.exp(res - np.max(res))
                softmax_res = res / np.sum(res)

                predict = np.argmax(softmax_res)                # 预测结果
                print(predict)
                if predict == self.test_label[i]:
                    accuracy += 1

            if s == 0:
                print(str(s + 1) + "st accuracy: ",
                      float(accuracy) / float(self.test_sep[s + 1] - self.test_sep[s]))
            elif s == 1:
                print(str(s + 1) + "nd accuracy: ",
                      float(accuracy) / float(self.test_sep[s + 1] - self.test_sep[s]))
            elif s == 2:
                print(str(s + 1) + "rd accuracy: ",
                      float(accuracy) / float(self.test_sep[s + 1] - self.test_sep[s]))
            else:
                print(str(s+1) + "th accuracy: ",
                      float(accuracy) / float(self.test_sep[s + 1] - self.test_sep[s]))
            print()


class Model2:
    '''
    knn模型
    '''
    def __init__(self, train_path):
        self.train_data = []                            # 训练数据
        self.train_label = []                           # 训练标签

        # 读取训练数据
        f = open(train_path, "r")
        for line in f.readlines():
            values = line.split()
            tmp_list = []
            for i in range(len(values) - 1):
                tmp_list.append(float(values[i]))
            self.train_data.append(tmp_list)
            self.train_label.append(int(values[-1]))
        f.close()

        self.train_length = len(self.train_data)
        self.train_data = np.array(self.train_data, dtype=np.float_)
        self.train_label = np.array(self.train_label, dtype=np.int_)

    def test(self, test_data):
        k = 8                                                       # 取8最近邻
        knn = []                                                    # 记录最近领的距离以及标签

        # 随机抽取 self.train_length//2 条训练数据
        sample = [i for i in range(self.train_length // 2)]
        sample = random.sample(sample, self.train_length // 2)
        train_data = self.train_data[sample, :]
        train_label = self.train_label[sample]

        # 寻找knn
        for i in range(self.train_length//2):
            dist = np.mean((test_data - train_data[i, :]) ** 2)
            if len(knn) < k:
                knn.append((dist, train_label[i]))
            else:
                max_dist = -1
                max_index = 0
                for j in range(len(knn)):
                    if knn[j][0] > max_dist:
                        max_dist = knn[j][0]
                        max_index = j
                if max_dist > dist:
                    knn[max_index] = (dist, train_label[i])

        predict = 0
        for each in knn:
            if each[1] == 0:
                predict -= 1
            else:
                predict += 1 * 1.5                # 由于前景数据较少，增加前景的权重

        if predict > 0:
            return 1
        else:
            return 0


class Model3:
    '''
    Random Forest模型
    '''
    def __init__(self, train_path):
        self.train_data = []                                    # 训练数据
        self.train_label = []                                   # 训练标签

        # 读取训练数据
        f = open(train_path, "r")
        for line in f.readlines():
            values = line.split()
            tmp_list = []
            for i in range(len(values) - 1):
                tmp_list.append(float(values[i]))
            self.train_data.append(tmp_list)
            self.train_label.append(int(values[-1]))
        f.close()

        self.train_data = np.array(self.train_data, dtype=np.float_)
        self.train_label = np.array(self.train_label, dtype=np.int_)

        # 随机森林
        self.rf = RandomForestClassifier()
        self.rf.fit(self.train_data, self.train_label)

    def test(self, test_data):
        return self.rf.predict(test_data)       # 预测结果
