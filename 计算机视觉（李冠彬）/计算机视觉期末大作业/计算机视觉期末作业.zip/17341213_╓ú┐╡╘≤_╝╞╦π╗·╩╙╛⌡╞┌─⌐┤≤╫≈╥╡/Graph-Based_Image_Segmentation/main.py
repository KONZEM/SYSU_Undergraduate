import matplotlib.pyplot as plt
from image_segmentation import *
from iou import *


if __name__ == "__main__":
    images_path = "../data/imgs/"       # 图像路径
    gt_path = "../data/gt/"             # ground truth路径
    start_num = 13                      # 学号尾号13，即第一张要处理的图像的编号为13
    sigma = 0.8                         # 高斯滤波的参数
    min_size = 20                       # 每个区域的像素不低于20

    for i in range(10):                 # 测试图像的编号分别为13，113，213，313，...，813，913
        k = 300                         # 阈值参数
        while True:                     # 分割出的区域的数量必须在50~100之间，否则调整参数k
            img, seg_img, disjoint_set = segment(images_path + str(start_num + i * 100) + ".png",
                                                 sigma, k, min_size)    # 原图，分割图，并查集
            if disjoint_set.get_set_size() > 100:       # 数量过多，说明阈值过小，调大
                k += 100
            elif disjoint_set.get_set_size() < 50:      # 数量过少，说明阈值过大，调小
                k -= 50
            else:
                break

        # 真正的gt，根据分割结果和真正的gt得到的新gt，iou值
        gt_img, new_gt_img, iou = cal_iou(gt_path + str(start_num + i * 100) + ".png", disjoint_set)

        print("The " + str(start_num + i * 100) + "th image: ")
        print("the number of segmentation = " + str(disjoint_set.get_set_size()))
        print("iou = " + str(iou))
        print()

        # img = img[:, :, (2, 1, 0)]
        fig = plt.figure(figsize=(7, 6))
        subfig = fig.add_subplot(2, 2, 1)
        plt.imshow(img)
        subfig.set_title("origin image")
        subfig = fig.add_subplot(2, 2, 2)
        plt.imshow(seg_img)
        subfig.set_title("segmented image")
        subfig = fig.add_subplot(2, 2, 3)
        plt.imshow(gt_img)
        subfig.set_title("ground truth")
        subfig = fig.add_subplot(2, 2, 4)
        plt.imshow(new_gt_img, cmap="gray")
        subfig.set_title("based on segmented image and ground truth")

    plt.show()
