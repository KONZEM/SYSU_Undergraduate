import cv2
import numpy as np


def cal_iou(gt_path, disjoint_set):
    '''
    :param gt_path: 真正gt的路径
    :param disjoint_set: 记录分割的并查集
    :return: 真正的gt，根据分割结果和真正的gt得到的新gt，iou值
    '''
    gt_img = cv2.imread(gt_path)                            # 真正的gt
    height, width, _ = gt_img.shape                         # 图像的高、宽
    region_map = {}                                         # 记录同个区域内的像素点
    new_gt_img = np.zeros([height, width], dtype=np.uint8)  # 根据分割结果和真正的gt得到的新gt
    num = 0                                                 # iou的分子
    den = 0                                                 # iou的分母

    for i in range(height):
        for j in range(width):
            leader = disjoint_set.find(i * width + j)       # 像素点所在区域的leader
            if leader in region_map:                        # 加入到已有的集合
                region_map[leader].append(i * width + j)
            else:                                           # 新建一个集合
                region_map[leader] = [i * width + j]

    for key in region_map.keys():                           # 对于每个区域
        value = region_map[key]
        color = 0
        for each in value:                                  # 对照真正的gt，查看对应像素点是前景还是背景
            if np.sum(gt_img[int(each / width), each % width, :]) == 0:
                color -= 1
            else:
                color += 1
        if color > 0:                                       # 大于50%的像素点为前景，则该区域为前景区域
            for each in value:
                new_gt_img[int(each / width), each % width] = 255
        else:                                               # 否则为背景区域
            for each in value:
                new_gt_img[int(each / width), each % width] = 0

    for i in range(height):                                 # 计算iou
        for j in range(width):
            if np.sum(gt_img[i, j, :]) == 765 and new_gt_img[i, j] == 255:
                num += 1
                den += 1
            elif np.sum(gt_img[i, j, :]) == 765 or new_gt_img[i, j] == 255:
                den += 1

    return gt_img, new_gt_img, float(num)/float(den)


