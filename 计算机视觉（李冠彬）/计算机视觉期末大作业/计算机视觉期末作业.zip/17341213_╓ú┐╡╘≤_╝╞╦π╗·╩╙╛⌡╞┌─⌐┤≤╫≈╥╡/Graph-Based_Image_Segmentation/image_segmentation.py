import cv2
import numpy as np
from utils import *


def segment(images_path, sigma, k, min_size):
    '''
    :param images_path: 图像路径
    :param sigma: 高斯滤波的参数
    :param k: 阈值参数
    :param min_size: 每个区域的像素不低于20
    :return: 原图，分割图，并查集
    '''
    img = cv2.imread(images_path)
    # 三通道滤波后叠加变成模糊后的图像
    blur_blue = cv2.GaussianBlur(img[:, :, 0], (0, 0), sigma)
    blur_green = cv2.GaussianBlur(img[:, :, 1], (0, 0), sigma)
    blur_red = cv2.GaussianBlur(img[:, :, 2], (0, 0), sigma)
    blur_img = cv2.merge([blur_blue, blur_green, blur_red]).astype(np.int16)
    height, width, _ = blur_img.shape               # 图像的高、宽

    # 记录8邻域的边并计算不相似度
    edges = []
    num_edges = 0
    for i in range(height):
        for j in range(width):
            if i < height - 1:
                edge = Edge(i * width + j, (i + 1) * width + j,
                            cal_diff(blur_img[i, j, :], blur_img[i + 1, j, :]))
                edges.append(edge)
                num_edges += 1
                # print(i * width + j, (i + 1) * width + j)
            if j < width - 1:
                edge = Edge(i * width + j, i * width + j + 1,
                            cal_diff(blur_img[i, j, :], blur_img[i, j + 1, :]))
                edges.append(edge)
                num_edges += 1
                # print(i * width + j, i * width + j + 1)
            if i > 0 and j < width - 1:
                edge = Edge(i * width + j, (i - 1) * width + j + 1,
                            cal_diff(blur_img[i, j, :], blur_img[i - 1, j + 1, :]))
                edges.append(edge)
                num_edges += 1
                # print(i * width + j, (i - 1) * width + j + 1)
            if i < height - 1 and j < width - 1:
                edge = Edge(i * width + j, (i + 1) * width + j + 1,
                            cal_diff(blur_img[i, j, :], blur_img[i + 1, j + 1, :]))
                edges.append(edge)
                num_edges += 1
                # print(i * width + j, (i + 1) * width + j + 1)
    # 根据不相似度逆序排序
    edges.sort(key=lambda x: x.diff)

    disjoint_set = Disjoint_Set(height * width)                         # 初始化并查集
    threshold = [float(k) / 1.0 for _ in range(height * width)]         # 每个集合的内部不相似度

    # 分割
    for i in range(num_edges):
        edge = edges[i]
        x_leader = disjoint_set.find(edge.vertex1)
        y_leader = disjoint_set.find(edge.vertex2)
        if x_leader != y_leader:
            if edge.diff < threshold[x_leader] and edge.diff < threshold[y_leader]:     # 边的不相似度小于两个集合的内部不相似度
                xy_leader = disjoint_set.union(x_leader, y_leader)
                threshold[xy_leader] = edge.diff + float(k) / disjoint_set.get_ele_size(xy_leader)  # 更新合并后的集合的内部不相似度

    # 优先合并两个像素少于20的区域
    for i in range(num_edges):
        edge = edges[i]
        x_leader = disjoint_set.find(edge.vertex1)
        y_leader = disjoint_set.find(edge.vertex2)
        if x_leader != y_leader and (disjoint_set.get_ele_size(x_leader) < min_size
                                     and disjoint_set.get_ele_size(y_leader) < min_size):
            disjoint_set.union(x_leader, y_leader)
    # 然后合并其中一个像素少于20的区域
    for i in range(num_edges):
        edge = edges[i]
        x_leader = disjoint_set.find(edge.vertex1)
        y_leader = disjoint_set.find(edge.vertex2)
        if x_leader != y_leader and (disjoint_set.get_ele_size(x_leader) < min_size
                                     or disjoint_set.get_ele_size(y_leader) < min_size):
            disjoint_set.union(x_leader, y_leader)

    seg_img = np.zeros(shape=(height, width, 3), dtype=np.uint8)        # 分割后图像
    colors = get_ncolor(disjoint_set.get_set_size())                    # 获取一定数量的颜色
    color_index = 0                                                     # 用到第几个色了
    color_map = {}                                                      # 记录区域的颜色
    # 给每个区域上色
    for i in range(height):
        for j in range(width):
            leader = disjoint_set.find(i * width + j)
            if leader in color_map:
                seg_img[i, j, :] = colors[color_map[leader]]
            else:
                color_map[leader] = color_index
                seg_img[i, j, :] = colors[color_index]
                color_index += 1

    return img, seg_img, disjoint_set
